# FSA Food Alerts API Python Wrapper

This is a python wrapper for the food alerts API, making it easier to interact with the API by abstracting the details of HTTP requests to the API.
