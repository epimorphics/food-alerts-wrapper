class RelatedMedia:
    def __init__(self, ID, title):
        self.id = ID;
        self.title = title;