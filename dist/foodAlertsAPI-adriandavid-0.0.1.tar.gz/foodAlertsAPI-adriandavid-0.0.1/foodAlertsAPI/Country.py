class Country:
    def __init__(self, ID, label):
        self.id = ID;
        self.label = label;